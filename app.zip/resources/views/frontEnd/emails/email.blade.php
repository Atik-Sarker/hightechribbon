<h3>You have a new massage form Hightech Ribbon</h3>
 <p><b>Name :</b> {{$name}}</p>
 <p><b>Phone :</b> {{$contact_phone}}</p>
 <p><b>Sent Via :</b>{{$contact_email}}</p>
 <b>Visitor says :</b>{{$contact_text}}
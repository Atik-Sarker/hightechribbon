<?php $__env->startSection('title','Slider Manage'); ?>
<?php $__env->startSection('main_content'); ?>
 <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            <h3 class="card-title">Manage slider information</h3>
      			<div class="short_button">
              <a href="<?php echo e(url('editor/slider/add')); ?>"><i class="fa fa-plus"></i>Add</a>
      			</div>
          </div>
          <!-- /.card-header -->
            <div class="card-body user-border">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sl</th>
                  <th>Image</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $show_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><img src="<?php echo e(asset($value->image)); ?>" class="responsive_image" alt=""></td>
                  <td> <?php echo e($value->status==1?'Active':'Inactive'); ?></td>
                  <td>
                  	<ul class="action_buttons">
                  		<li>
                  			<?php if($value->status==1): ?>
                  			<form action="<?php echo e(url('editor/slider/unpublished')); ?>" method="POST">
                  				<?php echo csrf_field(); ?>
                  				<input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                  				<button type="submit" class="thumbs_up" title="unpublished"><i class="fa fa-thumbs-up"></i></button>
                  			</form>
                  			<?php else: ?>
	                  			<form action="<?php echo e(url('editor/slider/published')); ?>" method="POST">
	                  				<?php echo csrf_field(); ?>
	                  				<input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
	                  				<button type="submit" class="thumbs_down" title="published"><i class="fa fa-thumbs-down"></i></button>
	                  			</form>
                  			<?php endif; ?>
                  		</li>
                  		<li>
                  			<a class="edit_icon" href="<?php echo e(url('editor/slider/edit/'.$value->id)); ?>" title="Edit"><i class="fa fa-edit"></i></a>
                  		</li>
                  		<li>
                  			<form action="<?php echo e(url('editor/slider/delete')); ?>" method="POST">
                  				<?php echo csrf_field(); ?>
                  				<input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                  				<button type="submit" onclick="return confirm('Are you delete this manufacture')" class="trash_icon" title="Delete"><i class="fa fa-trash"></i></button>
                  			</form>
                  		</li>
                  	</ul>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
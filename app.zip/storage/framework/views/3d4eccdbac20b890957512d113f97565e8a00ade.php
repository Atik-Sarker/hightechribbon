<?php $__env->startSection('title','User Update'); ?>

<?php $__env->startSection('main_content'); ?>
<section class="content">
  <div class="container-fluid">
    <div class="card card-default">
      <div class="card-header">
          <h3 class="card-title">Update user information</h3>
          <div class="short_button">
            <a href="<?php echo e(url('/superadmin/user/manage')); ?>"><i class="fa fa-cogs"></i>Manage</a>
          </div>
      </div>
      <!--card-header -->
            <div id="form_body" class="card-body">
              <div class="row">
                <div class="col-md-8">
                  <div class="custom-bg">
                    <form action="<?php echo e(url('/superadmin/user/update')); ?>" method="POST" enctype="multipart/form-data" name="editForm">
                      <?php echo csrf_field(); ?>
                      <div class="row">
                        <input type="hidden" value="<?php echo e($edit_data->id); ?>" name="hidden_id">
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label>Name</label>
                              <input type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->name); ?>">

                              <?php if($errors->has('name')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                              </span>
                              <?php endif; ?>
                            </div>
                        </div>
                      <!-- /.form-group -->
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->username); ?>">

                                <?php if($errors->has('username')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('username')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <!--form-group -->
                        <div class="col-sm-6">
                          <div class="form-group">
                              <label>Email</label>
                              <input type="text" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->email); ?>">

                              <?php if($errors->has('email')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->first('email')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        </div>
                         <!--form-group -->

                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->phone); ?>">

                            <?php if($errors->has('phone')): ?>
                            <span class="invalid-feedback" role="alert">
                               <strong><?php echo e($errors->first('phone')); ?></strong>
                            </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <!-- /.form-group -->

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Designation</label>
                                <input type="text" name="designation" class="form-control<?php echo e($errors->has('designation') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->designation); ?>">

                                <?php if($errors->has('designation')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('designation')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- /.form-group -->
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="Picture">Picture</label>
                                <input type="file" name="image" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('image')); ?>" accept="image/*">
                                <img class="backend_image" src="<?php echo e(asset($edit_data->image)); ?>">
                                <?php if($errors->has('image')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('image')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- form-group end -->
                      <div class="col-sm-6">
                          <div class="form-group">
                              <button type="submit" class="btn submit-button">submit</button>
                              <button type="reset" class="btn btn-default">clear</button>
                          </div>
                      </div>
                      <!-- /.form-group -->
                 </div>
                </div>
              </div>
            <!-- /.col -->
                <div class="col-md-4">
                    <div class="custom-bg">
                        <div class="form-group">
                          <div class="custom-cart-title">
                            <strong>Select User Role</strong>
                          </div>
                           <div class="box-body">
                                <input class="form-control<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>" type="radio" id="superadmin" name="role_id" value="1">
                                <label for="superadmin">Superadmin</label>
                                <?php if($errors->has('role_id')): ?>
                                <span class="invalid-feedback">
                                  <strong><?php echo e($errors->first('role_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                           <div class="box-body">
                                <input class="form-control<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>" type="radio" id="admin" name="role_id" value="2">
                                <label for="admin">Admin</label>
                                <?php if($errors->has('role_id')): ?>
                                <span class="invalid-feedback">
                                  <strong><?php echo e($errors->first('role_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                           <div class="box-body">
                                <input class="form-control<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>" type="radio" id="editor" name="role_id" value="3">
                                <label for="editor">Editor</label>
                                <?php if($errors->has('role_id')): ?>
                                <span class="invalid-feedback">
                                  <strong><?php echo e($errors->first('role_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                           <div class="box-body">
                                <input class="form-control<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>" type="radio" id="author" name="role_id" value="4">
                                <label for="author">Author</label>
                                <?php if($errors->has('role_id')): ?>
                                <span class="invalid-feedback">
                                  <strong><?php echo e($errors->first('role_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>

                        </div>
                      </div>
                      <div class="custom-bg  mrt-30">
                        <div class="custom-cart-title">
                          <strong>Publication Status</strong>
                        </div>

                        <div class="box-body pub-stat display-inline">
                            
                            <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" id="active" name="status" value="1">
                            <label for="active">Active</label>
                            <?php if($errors->has('status')): ?>
                            <span class="invalid-feedback">
                              <strong><?php echo e($errors->first('status')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="box-body pub-stat display-inline">
                            <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" value="0" id="inactive">
                            <label for="inactive">Inactive</label>
                            <?php if($errors->has('status')): ?>
                            <span class="invalid-feedback">
                              <strong><?php echo e($errors->first('status')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                      </div>
                    </div>
                </div>
              </form>
          </div>
        <!--card-body-->
      </div>
      <!--card-->
    </div>
  <!--container-fluid-->
  </section>
  <!-- /.content -->
  <script type="text/javascript">
        document.forms['editForm'].elements['role_id'].value=<?php echo e($edit_data->role_id); ?>

        document.forms['editForm'].elements['status'].value=<?php echo e($edit_data->status); ?>

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
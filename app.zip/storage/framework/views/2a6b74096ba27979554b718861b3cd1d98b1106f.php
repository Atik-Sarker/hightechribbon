<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from adminlte.io/themes/dev/AdminLTE/index2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 Jul 2018 04:26:40 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Yourstore | <?php echo $__env->yieldContent('title','Dashboard'); ?></title>

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/plugins/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/custom/css/custom.css">
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/custom/css/toastr.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/custom/css/bootstrap3-wysihtml5.min.css">
  <!-- Google Font: Source Sans Pro -->

   <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/plugins/select2/select2.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/plugins/datatables/dataTables.bootstrap4.css}}">

  <!-- toastr css -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/css/toastr.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd')); ?>/css/custom.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
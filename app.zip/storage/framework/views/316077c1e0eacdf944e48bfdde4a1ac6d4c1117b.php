<!-- head section -->
  <?php echo $__env->make('backEnd.layouts.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- head section end-->

<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
    <?php echo $__env->make('backEnd.layouts.includes.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('backEnd.layouts.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <?php echo $__env->make('backEnd.layouts.includes.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.content-header -->

    <!-- Main content -->
    <?php echo $__env->yieldContent('main_content'); ?>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php echo $__env->make('backEnd.layouts.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

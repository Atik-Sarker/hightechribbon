<?php $__env->startSection('aboutpage'); ?>
<section id="breadcrumb">
        <div class="breadcrumb-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="bread-crumb">
                        <div class="bread-crumb-inner">
                            <h1><?php echo e(request()->segment(2)); ?></h1>
                            <ul class="m-top20">
                                <li class="active"><a href="index.html">Home</a></li>
                                <li>
                                    <div class="divider"></div>
                                </li>
                                <li><a><?php echo e(request()->segment(2)); ?></a></li>
                            </ul>
                        </div>
                    </div>
                    <!--bread-crumb end-->
                </div>
                <!--col end-->
            </div>
            <!--row end-->
        </div>
        <!--container end-->
    </section>
    <section id="product" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2><?php echo e(request()->segment(2)); ?></h2>
                    </div>
                </div>
                <!--col end-->
            </div>
            <!--row end-->
            <div class="row">
                <?php $__currentLoopData = $categoryproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="product-item">
                        <img src="<?php echo e(asset($value->image)); ?>" alt="">
                        <p><?php echo e($value->name); ?></p>
                        <a class="btn-button" href="<?php echo e(url('product/'.$value->code)); ?>">view details</a>
                    </div>
                </div>
                <!--col end-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!--row end-->
        </div>
        <!--container end-->
    </section>
    <!--Product section end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content m-top30">
    <div class="add-form">
        <form action="<?php echo e(url('/password/updated')); ?>"  enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="form-group">
                        <div class="box box-success">
                            <div class="box-header with-border padding20">
                                <h3 class="box-title profile-title">Change Password</h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body padding20">
                                <div class="row">

                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for="old_password" class="col-form-label text-md-right"><?php echo e(__('Old Password')); ?></label>

                                            <div class="">
                                                <input id="old_password" type="password" class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" name="old_password">

                                                <?php if($errors->has('old_password')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('old_password')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for="new_password" class="col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>

                                            <div class="">
                                                <input id="new_password" type="password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password">

                                                <?php if($errors->has('new_password')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('new_password')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for="password-confirm" class="col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                                            <div class="">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              
                              
                            </div>
                            <div class="box-footer padding20">
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                            <!-- /.box-body -->
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- /.row -->
</section>
<?php echo $__env->make('backEnd.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
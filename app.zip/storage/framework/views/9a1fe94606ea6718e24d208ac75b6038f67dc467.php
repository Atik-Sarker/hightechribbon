<?php $__env->startSection('title','Category Manage'); ?>
<?php $__env->startSection('main_content'); ?>
 <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            <h3 class="card-title">Manage Category information</h3>
            <div class="short_button">
              <a href="<?php echo e(url('editor/contact/create')); ?>"><i class="fa fa-plus"></i>Add</a>
            </div>
          </div>
          <!-- /.card-header -->
            <div class="card-body user-border">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sl</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $contactInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($contactInfo->phone); ?></td>
                  <td><?php echo e($contactInfo->email); ?></td>
                  <td><?php echo e($contactInfo->address); ?></td>
                  <td><?php echo e($contactInfo->status==1?'Active':'Inactive'); ?></td>
                  <td>
                    <ul class="action_buttons">
                      <li>
                        <?php if($contactInfo->status==1): ?>
                        <form action="<?php echo e(url('editor/contact/status',$contactInfo->id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="status" value="0">
                          <button type="submit" class="thumbs_up" title="unpublished"><i class="fa fa-thumbs-down"></i></button>
                        </form>
                        <?php else: ?>
                          <form action="<?php echo e(url('editor/contact/status',$contactInfo->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="1">
                            <button type="submit" class="thumbs_down" title="published"><i class="fa fa-thumbs-up"></i></button>
                          </form>
                        <?php endif; ?>
                      </li>
                      <li>
                        <a class="edit_icon" href="<?php echo e(url('editor/contact/edit/'.$contactInfo->id)); ?>" title="Edit"><i class="fa fa-edit"></i></a>
                      </li>
                      <li>
                        <form action="<?php echo e(url('editor/contact/delete',$contactInfo->id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <button type="submit" onclick="return confirm('Are you sure to delete this')" class="trash_icon" title="Delete"><i class="fa fa-trash"></i></button>
                        </form>
                      </li>
                    </ul>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
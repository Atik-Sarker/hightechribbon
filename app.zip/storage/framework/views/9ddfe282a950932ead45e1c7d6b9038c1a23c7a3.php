
<?php $__env->startSection('content'); ?>
	<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Add user information</h3>
      			<div class="short_button">
              <a href="<?php echo e(url('/superadmin/user/manage')); ?>"><i class="fa fa-cogs"></i>Manage</a>
      			</div>
          </div>
          <!-- /.card-header -->
          <div id="form_body" class="card-body">
           fe
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->

      
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
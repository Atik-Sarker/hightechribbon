<h3>You have a new massage form Hightech Ribbon</h3>
 <p><b>Name :</b> <?php echo e($name); ?></p>
 <p><b>Phone :</b> <?php echo e($contact_phone); ?></p>
 <p><b>Sent Via :</b><?php echo e($contact_email); ?></p>
 <b>Visitor says :</b><?php echo e($contact_text); ?>